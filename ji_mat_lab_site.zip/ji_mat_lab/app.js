/* ЖИ MAT-LAB — ашық демонстрациялық прототип.
   Нақты ЖИ үшін /api/tutor және /api/generate серверлік endpoint-терін іске қосыңыз.
   API кілттерін app.js немесе браузерге жіберілетін файлдарға салмаңыз. */
const $ = (id) => document.getElementById(id);
const STORAGE_KEY = "jiMatLabResults_v1";

const tasks = {
  percent: {
    title: "Пайызды өмірде қолдану",
    text: "Дүкенде бағасы 24 000 теңге болатын сөмкеге 20% жеңілдік жасалды. Сөмкенің жаңа бағасын анықта.",
    question: "Жеңілдіктің мөлшерін қалай есептеп, соңғы бағаны қалай табуға болады?",
    answer: ["19200", "19 200", "19 200"],
    solution: "20% жеңілдік: 24 000 × 0,20 = 4 800 теңге. Соңғы баға: 24 000 − 4 800 = 19 200 теңге.",
    hint: "Алдымен 20%-ды ондық бөлшекке айналдыр: 20% = 0,20. Содан кейін бастапқы бағаны 0,20-ға көбейт. Соңында жеңілдік сомасын бастапқы бағадан азайт."
  },
  ratio: {
    title: "Пропорция арқылы есептеу",
    text: "4 адамға арналған тағамға 300 г ұн қажет. 10 адамға осы тағамды әзірлеу үшін қанша ұн керек?",
    question: "Адам саны мен ұн мөлшерінің арасындағы тәуелділікті қалай пайдаланасың?",
    answer: ["750", "750 г"],
    solution: "Бір адамға 300 ÷ 4 = 75 г. Он адамға 75 × 10 = 750 г ұн қажет.",
    hint: "Алдымен 300 грамды 4 адамға бөліп, бір адамға қанша ұн керегін тап. Кейін шыққан мәнді 10-ға көбейт."
  },
  function: {
    title: "Такси құнын модельдеу",
    text: "Таксидің бастапқы төлемі 500 теңге, ал әр километрге 150 теңге қосылады. 6 км жолдың құнын тап және тәуелділікті формуламен жаз.",
    question: "Қашықтықты x деп белгілесек, жалпы төлем қандай өрнекпен беріледі?",
    answer: ["1400", "1 400", "y=500+150x", "y = 500 + 150x"],
    solution: "Модель: y = 500 + 150x. 6 км үшін y = 500 + 150 × 6 = 1 400 теңге.",
    hint: "Жалпы құн екі бөліктен тұрады: бастапқы 500 теңге және қашықтыққа байланысты 150 теңгеден төлем. 6 км үшін 150-ді 6-ға көбейт."
  },
  statistics: {
    title: "Деректерді талдау",
    text: "Оқушы бір аптада 2, 3, 1, 4, 5, 3 және 3 сағат кітап оқыды. Орташа оқу уақытын және ең жиі кездесетін мәнді анықта.",
    question: "Орташа мәнді табу үшін қандай амалдар қажет? Қай сан ең жиі қайталанады?",
    answer: ["3", "орташа 3", "3 сағат"],
    solution: "Қосындысы 21 сағат. 21 ÷ 7 = 3 сағат. Ең жиі кездесетін мән де 3.",
    hint: "Барлық жеті мәнді қосып, 7-ге бөл. Ең жиі кездесетін мәнді табу үшін сандардың қайсысы көбірек қайталанатынын сана."
  },
  geometry: {
    title: "Бөлме еденінің ауданын есептеу",
    text: "Ұзындығы 8 м, ені 5 м болатын бөлменің еденіне жабын төселеді. Қанша шаршы метр жабын қажет? Қорытындыңды түсіндір.",
    question: "Тік төртбұрыштың ауданын табу үшін қандай формула қолданылады?",
    answer: ["40", "40 м2", "40 м²"],
    solution: "Тік төртбұрыш ауданы S = a × b. S = 8 × 5 = 40 м².",
    hint: "Еден тік төртбұрыш пішінді. Оның ауданын табу үшін ұзындығын еніне көбейт."
  },
  quadratic: {
    title: "Квадрат теңдеуді зерттеу",
    text: "x² − 5x + 6 = 0 теңдеуінің түбірлерін тап және оларды бастапқы теңдеуге қойып тексер.",
    question: "Көбейтіндісі 6-ға, ал қосындысы 5-ке тең екі санды таба аласың ба?",
    answer: ["2 және 3", "2, 3", "x=2, x=3", "x = 2 және x = 3"],
    solution: "x² − 5x + 6 = (x − 2)(x − 3) = 0. Сондықтан x = 2 немесе x = 3.",
    hint: "6 санының көбейткіш жұптарын қарастыр: 1 және 6; 2 және 3. Қай жұптың қосындысы 5-ке тең?"
  }
};

function readResults() {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]"); }
  catch { return []; }
}
function saveResults(results) {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(results)); }
  catch (e) { console.warn("Бұл браузерде жергілікті сақтау қолжетімсіз.", e); }
}
function showView(view) {
  document.querySelectorAll(".view").forEach(el => el.classList.toggle("active", el.id === `view-${view}`));
  document.querySelectorAll("[data-view]").forEach(el => el.classList.toggle("active", el.dataset.view === view && el.classList.contains("nav-link")));
  $("mainNav").classList.remove("open");
  if (view === "teacher" || view === "progress") renderResults();
  window.scrollTo({top: 0, behavior: "smooth"});
}
document.querySelectorAll("[data-view]").forEach(el => el.addEventListener("click", () => showView(el.dataset.view)));
$("menuToggle").addEventListener("click", () => $("mainNav").classList.toggle("open"));

function currentTask() { return tasks[$("topicSelect").value] || tasks.percent; }
function renderTask() {
  const task = currentTask();
  $("taskGrade").textContent = `${$("gradeSelect").value}-СЫНЫП`;
  $("taskLevel").textContent = $("levelSelect").value.toLocaleUpperCase("kk-KZ");
  $("taskTitle").textContent = task.title;
  $("taskText").textContent = task.text;
  $("taskQuestion").textContent = task.question;
  $("studentWork").value = "";
  $("feedback").className = "feedback hidden";
}
$("loadTask").addEventListener("click", renderTask);

function normalize(text) {
  return String(text || "").toLowerCase().replace(/\s/g, "").replace(/,/g, ".").replace(/₸|теңге|сағат|грамм|г|м²|м2/g, "");
}
function evaluateAnswer() {
  const work = $("studentWork").value.trim();
  if (!work) {
    $("feedback").className = "feedback error";
    $("feedback").innerHTML = "<strong>Алдымен шешу жолын жаз.</strong> Формуланы, есептеуді немесе өз ойыңды енгізіп көр.";
    return;
  }
  const task = currentTask();
  const normalized = normalize(work);
  const matches = task.answer.some(a => normalized.includes(normalize(a)));
  const score = matches ? 8 : 4;
  const record = {
    date: new Date().toISOString(),
    grade: $("gradeSelect").value,
    topic: $("topicSelect").selectedOptions[0].textContent,
    level: $("levelSelect").value,
    score,
    maxScore: 10,
    answer: work.slice(0, 500)
  };
  const results = readResults();
  results.unshift(record);
  saveResults(results.slice(0, 200));
  $("feedback").className = `feedback ${matches ? "" : "error"}`;
  $("feedback").innerHTML = `<strong>${matches ? "Жақсы жұмыс! Үлгі жауапқа сәйкес келетін нәтиже табылды." : "Жауабыңды қайта тексеріп көр."}</strong><p>${task.solution}</p><p><b>Демо-бағалау:</b> ${score}/10 ұпай. Бұл қарапайым үлгілік тексеру; толық бағалау мұғалім критерийлері бойынша жүргізілуі керек.</p>`;
  renderResults();
}
$("checkAnswer").addEventListener("click", evaluateAnswer);
$("askHint").addEventListener("click", () => {
  const task = currentTask();
  addMessage("assistant", `Бағыттаушы көмек:\n${task.hint}\n\nЕнді есепті өзің шығарып көр. Қаласаң, шешу жолыңды жазып, тексеруге болады.`);
  showView("tutor");
});

function addMessage(role, text) {
  const node = document.createElement("div");
  node.className = `message ${role}`;
  node.textContent = text;
  $("chatMessages").appendChild(node);
  $("chatMessages").scrollTop = $("chatMessages").scrollHeight;
}
function demoTutorReply(prompt) {
  const q = prompt.toLowerCase();
  if (q.includes("пайыз")) return "Пайыз — санның жүзден бір бөлігі. Мысалы, 20% = 20/100 = 0,2.\nБағыттаушы сұрақ: 24 000 теңгенің 20%-ын табу үшін 24 000-ды қандай санға көбейтесің?";
  if (q.includes("функц")) return "Функция бір шаманың екінші шамаға тәуелділігін көрсетеді. Мысалы, такси құны y = 500 + 150x формуласымен берілуі мүмкін.\nБағыттаушы сұрақ: x нені білдіреді, ал 500 саны қандай мағына береді?";
  if (q.includes("есеп құрастыр") || q.includes("жаңа есеп")) return "Зерттеу есебі: дәптердің бағасы 350 теңге. Оқушы 6 дәптер сатып алды да, 3 000 теңге төледі. Қанша теңге қайтарым алады?\nАлдымен жалпы құнды тап, содан кейін оны төленген сомадан азайт.";
  if (q.includes("теңдеу")) return "Теңдеуді шешкенде белгісіздің мәнін табуға тырысамыз. Алдымен өрнекті ықшамдауға немесе көбейткіштерге жіктеуге бола ма, соны қарастыр.\nТеңдеуіңді толық жазсаң, шешу жолын табуға көмектесетін сұрақ қоямын.";
  return "Есепті шағын қадамдарға бөлейік.\n1. Не белгілі екенін жаз.\n2. Нені табу керегін анықта.\n3. Қажетті формуланы таңда.\n4. Есептеп, жауабыңды тексер.\n\nНақтырақ көмектесуім үшін есептің шартын немесе өз шешу жолыңды жібер.";
}
async function sendTutorMessage(text) {
  const prompt = text.trim();
  if (!prompt) return;
  addMessage("user", prompt);
  $("chatInput").value = "";
  // Нақты серверлік интеграция қосылса, жауап осы endpoint-тен алынады.
  // API кілті браузерде сақталмайды.
  try {
    const response = await fetch("/api/tutor", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({message: prompt, grade: $("gradeSelect").value, topic: $("topicSelect").selectedOptions[0].textContent})
    });
    if (response.ok) {
      const data = await response.json();
      if (data.reply) { addMessage("assistant", data.reply); return; }
    }
  } catch (_) { /* Серверлік API әзірге орнатылмаған — демо-жауапты қолданамыз. */ }
  addMessage("assistant", demoTutorReply(prompt) + "\n\nЕскерту: бұл алдын ала жазылған демо-жауап. Нақты ЖИ интеграциясы серверлік API қосылғаннан кейін іске қосылады.");
}
$("chatForm").addEventListener("submit", e => { e.preventDefault(); sendTutorMessage($("chatInput").value); });
document.querySelectorAll("[data-prompt]").forEach(btn => btn.addEventListener("click", () => sendTutorMessage(btn.dataset.prompt)));

$("generateTask").addEventListener("click", async () => {
  const grade = $("genGrade").value, topic = $("genTopic").value, level = $("genLevel").value;
  const box = $("generatedTask");
  box.classList.remove("hidden");
  box.textContent = "Есеп үлгісі дайындалуда…";
  try {
    const response = await fetch("/api/generate", {
      method: "POST", headers: {"Content-Type": "application/json"},
      body: JSON.stringify({grade, topic, level, language: "kk"})
    });
    if (response.ok) {
      const data = await response.json();
      if (data.task) { box.textContent = data.task; return; }
    }
  } catch (_) {}
  const examples = {
    "Пайыз және жеңілдік": `Есеп үлгісі (${grade}-сынып, ${level}): Бағасы 18 000 теңге болатын күртеге 15% жеңілдік жасалды. Жеңілдік сомасын және соңғы бағаны тап.`,
    "Пропорция": `Есеп үлгісі (${grade}-сынып, ${level}): 3 адамға 450 г күріш қажет. 8 адамға қанша күріш керек? Пропорция құр.`,
    "Сызықтық функция": `Есеп үлгісі (${grade}-сынып, ${level}): Велосипедті жалға алу 700 теңге, әр сағатқа тағы 400 теңге төленеді. x сағатқа төлем формуласын жаз.`,
    "Статистика": `Есеп үлгісі (${grade}-сынып, ${level}): 4, 6, 5, 7, 3 сандарының арифметикалық ортасын тап және нәтижені түсіндір.`,
    "Геометрия": `Есеп үлгісі (${grade}-сынып, ${level}): Ұзындығы 9 м, ені 4 м алаңның ауданын тап. Өлшем бірлігін көрсет.`,
    "Квадрат теңдеу": `Есеп үлгісі (${grade}-сынып, ${level}): x² − 7x + 12 = 0 теңдеуін шешіп, түбірлерін тексер.`
  };
  box.textContent = (examples[topic] || `Есеп үлгісі: ${topic}, ${grade}-сынып, ${level} деңгейі.`) + "\n\nБұл шаблондық демо-генератор. Жаңа мазмұнды нақты ЖИ арқылы құрастыру үшін /api/generate серверлік endpoint-ін қосыңыз.";
});

function fmtDate(date) {
  try { return new Date(date).toLocaleString("kk-KZ", {day:"2-digit", month:"short", hour:"2-digit", minute:"2-digit"}); }
  catch { return ""; }
}
function renderResults() {
  const results = readResults();
  const count = results.length;
  const average = count ? (results.reduce((s, r) => s + Number(r.score || 0), 0) / count).toFixed(1) : "—";
  const best = count ? Math.max(...results.map(r => Number(r.score || 0))) : "—";
  ["metricCount","progressCount"].forEach(id => { if ($(id)) $(id).textContent = count; });
  ["metricAverage","progressAverage"].forEach(id => { if ($(id)) $(id).textContent = average === "—" ? "—" : `${average}/10`; });
  if ($("metricBest")) $("metricBest").textContent = best === "—" ? "—" : `${best}/10`;
  if ($("progressTotal")) $("progressTotal").textContent = results.reduce((s, r) => s + Number(r.score || 0), 0);
  const html = results.length ? results.slice(0, 20).map(r => `<div class="result-item"><div><strong>${escapeHtml(r.topic || "Математика")}</strong><small>${escapeHtml(r.grade || "")}-сынып · ${escapeHtml(r.level || "")} · ${fmtDate(r.date)}</small></div><span class="score-badge">${Number(r.score || 0)}/${Number(r.maxScore || 10)}</span></div>`).join("") : '<p class="empty-state">Әзірге нәтиже жоқ. Зертханада тапсырма орындап көр.</p>';
  if ($("teacherResults")) $("teacherResults").innerHTML = html;
  if ($("progressResults")) $("progressResults").innerHTML = html;
}
function escapeHtml(text) {
  return String(text).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
$("exportResults").addEventListener("click", () => {
  const results = readResults();
  if (!results.length) { alert("Экспорттау үшін әзірге нәтиже жоқ."); return; }
  const rows = [["Күні","Сынып","Тақырып","Деңгей","Ұпай","Максимум","Жауап"], ...results.map(r => [r.date,r.grade,r.topic,r.level,r.score,r.maxScore,r.answer])];
  const csv = "\uFEFF" + rows.map(row => row.map(v => `"${String(v ?? "").replace(/"/g,'""')}"`).join(";")).join("\r\n");
  const url = URL.createObjectURL(new Blob([csv], {type:"text/csv;charset=utf-8;"}));
  const a = document.createElement("a"); a.href = url; a.download = "ji-mat-lab-natizheler.csv"; a.click(); URL.revokeObjectURL(url);
});
$("clearResults").addEventListener("click", () => {
  if (confirm("Осы браузерде сақталған барлық демо-нәтижені өшіресіз бе?")) {
    saveResults([]); renderResults();
  }
});
renderTask();
renderResults();
